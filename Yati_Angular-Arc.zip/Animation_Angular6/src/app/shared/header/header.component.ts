import { Component, OnInit, Input } from '@angular/core';
import { HomeService } from '../../home/services/home.service';
import { Area } from '../model/location';
import { UserProfile } from '../model/userprofile';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { UtilityClass } from '../utilites/helper-class';

@Component({
  selector: 'rsa-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
 
  isopen: Boolean = false;
  logoUrl : string;
  isHome: boolean;
  isKSA:boolean;
  isOman:boolean;
  private ut;
  sideNavData;
  areaData: Area[] = [];
  location: UserProfile[] = [];
  defaultcity:string;
  username:string;
  
  animationnav: string = this.isopen ? 'enter' : 'leave';


  constructor(private homeservice: HomeService, private router: Router) {
    }

  ngOnInit() {
      
      this.router.events.subscribe((event) =>{
      if (event instanceof NavigationEnd) {
          this.isHome = this.router.url === '/home' ? true : false;        
        }
    });

    this.getSideNavData();
    this.getAreaData();
    this.getUserData(); 
  }

  opensidebar(): void {
    this.isopen = !this.isopen;

  }

  close() {
    this.isopen = false;
  }

  getSideNavData(): void {
    this.homeservice.generateLeftMenu().subscribe((data) => {
      this.sideNavData = data;
    });
  }

  getAreaData(): void {
    this.homeservice.getArea().subscribe((data) => {
      this.areaData = data;
    });
  }

  getUserData(): void {
    this.homeservice.getUserInfo().subscribe((data) => {
       this.location = data.location;
       this.logoUrl = data.logourl;
       this.defaultcity = data.defaultcity;
       this.username = data.firstname+" "+data.lastname;
       this.isKSA=(this.logoUrl.indexOf('alamiya')>-1);
       this.isOman= (this.logoUrl.indexOf('oman')>-1);
       
    });
   
  }
}
