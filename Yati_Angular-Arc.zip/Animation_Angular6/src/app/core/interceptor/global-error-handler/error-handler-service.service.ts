import { Injectable, ErrorHandler } from '@angular/core';
import {
    HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpResponse, HttpErrorResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
export class AppConstants {
    public static get httpError(): string { return 'There was an HTTP error.'; }
    public static get javascriptError(): string { return 'There was a javascript error.'; }
    public static get forbiddenError(): string { return 'There was a forbidden error.'; }
    public static get somethingHappened(): string { return 'Nobody threw an Error but something happened!'; }
}

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {
    constructor(private router: Router, private alertService: AlertService) { }
    intercept(request: HttpRequest<any>, httpHandler: HttpHandler): Observable<HttpEvent<any>> {
        return httpHandler.handle(request)
            .pipe(
                catchError((error: HttpErrorResponse) => {
                    const date = new Date().toUTCString();
                    const errMsg = '';
                    if (error instanceof HttpErrorResponse) {
                        // The response body may contain clues as to what went wrong
                        switch (error.status) {
                            case 404: {
                                this.alertService.error('Page Not Found so redirecting to home');
                                setTimeout(() => {
                                    this.router.navigate(['/home']);
                                }, 0);
                                break;
                            }
                            case 500:
                            case 401: {
                                this.router.navigate(['/login']);
                                break;
                            }
                            case 403: {
                                console.error(date, AppConstants.forbiddenError, error.message);
                            }
                        }
                    } else {
                        console.error(date, AppConstants.javascriptError || AppConstants.somethingHappened);
                    }
                    return throwError(errMsg);
                }));
    }
}

