import { Injectable } from '@angular/core';
import { HttpHandler, HttpErrorResponse, HttpRequest, HttpResponse, HttpEvent } from '@angular/common/http';
import { tap, switchMap } from 'rxjs/operators';
import { catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { LoaderService } from '../loader/loader-service';

@Injectable()
export class LoaderInterceptorService {
    constructor(private loaderService: LoaderService) { }
    private servercallcount = 0;

    intercept(req: HttpRequest<any>, httpHandler: HttpHandler): Observable<HttpEvent<any>> {
        this.servercallcount++;
        if (this.servercallcount >= 1) {
            setTimeout(() => this.loaderService.showLoader(), 0);
        }
        return httpHandler.handle(req).pipe(
            tap((event) => {
                if (event instanceof HttpResponse) {
                    this.servercallcount--;
                    if (this.servercallcount === 0) {
                        setTimeout(() => this.loaderService.hideLoader(), 0);
                    }
                }
            }),
            catchError((err: HttpErrorResponse) => {
                this.servercallcount--;
                if (err instanceof HttpErrorResponse) {
                    setTimeout(() => this.loaderService.hideLoader(), 0);
                }
                if (err instanceof Error) {
                    return Observable.throw(err.message || err);
                }
            }));
    }
}
