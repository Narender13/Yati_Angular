import { Injectable } from '@angular/core';
import { HttpClient, } from '@angular/common/http';
import { map, catchError, shareReplay } from 'rxjs/operators';

import { RSAENDPOINTConstants } from '../../core/constants/rsa.api.end.points';

import { Observable } from 'rxjs';
import { Area } from '../../shared/model/location';
import { UserProfile } from '../../shared/model/userprofile';
import { EntityTypeHead } from '../modal/entitytypehead';
import { SideNavRouteInfo } from '../modal/sidenav';
import { handleErrorObservable } from '../../shared/utilites/helper';
import { FoldMenu } from '../modal/foldmenu';
import { MytaskRemainder } from '../modal/mytaskremainder';
import { HttpHeaders } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class HomeService {

    private cachedcategory: Observable<any>;
    private cachedentity: Observable<any>;
    private cachedarea: Observable<any>;
    private cachedcity: Observable<any>;


    constructor(private http: HttpClient) { }

    generateLeftMenu(): Observable<any> {
        return this.http.get<SideNavRouteInfo>(RSAENDPOINTConstants.MENUURL).pipe(
            map(res => res),
            catchError(handleErrorObservable));
    }


    populateDropDown(): Observable<any> {
        return this.http.get(RSAENDPOINTConstants.DROPDOWNMENU).pipe(
            map(res => res),
            catchError(handleErrorObservable));
    }

    getAreaData(): Observable<any> {
        return this.http.get<Area>(RSAENDPOINTConstants.AREA).pipe(
            map(res => res),
            catchError(handleErrorObservable));
    }

    

    getCategoryList(): Observable<any> {
        return this.http.get<FoldMenu>(RSAENDPOINTConstants.CATEGORY).pipe(
            map(res => res),
            catchError(handleErrorObservable));
    }

    getEntitySearchListData(): Observable<any> {
        return this.http.get<EntityTypeHead>(RSAENDPOINTConstants.ENTITYSEARCHLIST).pipe(
            map(res => res),
            catchError(handleErrorObservable));
    }
    getMyTaskRemainder(): Observable<MytaskRemainder> {
        return this.http.get<MytaskRemainder>(RSAENDPOINTConstants.SERVERAPI_MYTASK_REMINDER).pipe(
            map(res => res),
            catchError(handleErrorObservable));
    }

    getCategoryData() {
        if (!this.cachedcategory) {
            this.cachedcategory = this.getCategoryList().pipe(shareReplay(1));
        }
        return this.cachedcategory;
    }
    getEntityData() {
        if (!this.cachedentity) {
            this.cachedentity = this.getEntitySearchListData().pipe(shareReplay(1));
        }
        return this.cachedentity;
    }
    getArea() {
        if (!this.cachedarea) {
            this.cachedarea = this.getAreaData().pipe(shareReplay(1));
        }
        return this.cachedarea;
    }
    getUserData(): Observable<any> {
        return this.http.get<UserProfile>(RSAENDPOINTConstants.USERPROFILE).pipe(
       map(res => res),
       catchError(handleErrorObservable));
    }
    getUserInfo() {
        if (!this.cachedcity) {
            this.cachedcity = this.getUserData().pipe(shareReplay(1));
        }
        return this.cachedcity;
    }

    getColumnDisplayhead() {
        return [
            'GL Code',
            'Voucher No',
            'Voucher Type',
            'Voucher Date',
            'Transaction Type',
            'Class',
            'Transaction No',
            'Customer Name',
            'Amount'
        ];
    }
    getColumnPropertyNames() {
        return ['GLCode',
            'VoucherNo',
            'VoucherType',
            'VoucherDate',
            'TransactionType',
            'Class',
            'TransactionNo',
            'CustomerName',
            'Amount'
        ];
    }

}
