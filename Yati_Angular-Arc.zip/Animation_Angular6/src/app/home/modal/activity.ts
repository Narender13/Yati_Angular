export interface Activity {
    id: number;
    imgpath: string;
    item: string;
    path: string;
    name: string;
    checked?: boolean;
}
